class BackupThread extends Thread {
    @Override
    SelectableChannel getChannel() {
        assert isTransportLayerThread();
        return channel_;
    }
}
