class BackupThread extends Thread {
    public int getChannelCount() {
        return channelCount;
    }
}
