class BackupThread extends Thread {
    public String getChannelId() {
        return this.channelId;
    }
}
