class BackupThread extends Thread {
    public boolean isOpen() {
        return this.getChannel().isOpen();
    }
}
