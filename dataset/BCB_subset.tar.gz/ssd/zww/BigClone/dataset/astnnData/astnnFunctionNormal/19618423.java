class BackupThread extends Thread {
    public String getChannels() {
        if (channels == null) {
            return "1";
        } else {
            return channels;
        }
    }
}
