class BackupThread extends Thread {
    protected void setViewpoint() {
        setPaletteViewpoint();
        getGraphicalViewer().setContents(getModel());
    }
}
