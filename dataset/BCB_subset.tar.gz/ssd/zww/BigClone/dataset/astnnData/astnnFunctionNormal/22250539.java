class BackupThread extends Thread {
    public Long getChannelID() {
        return channelID;
    }
}
