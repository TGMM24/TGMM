class BackupThread extends Thread {
    String getChannelName() {
        return channel;
    }
}
