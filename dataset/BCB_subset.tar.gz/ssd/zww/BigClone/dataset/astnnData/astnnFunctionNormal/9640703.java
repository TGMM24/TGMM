class BackupThread extends Thread {
    public int getChannelId() {
        return channelId;
    }
}
