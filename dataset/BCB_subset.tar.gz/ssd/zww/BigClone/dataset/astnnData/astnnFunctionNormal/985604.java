class BackupThread extends Thread {
    public void preShowChange() {
        context.getShow().getChannels().removeNameListener(this);
    }
}
