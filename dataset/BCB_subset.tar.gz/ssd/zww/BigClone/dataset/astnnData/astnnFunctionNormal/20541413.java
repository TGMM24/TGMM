class BackupThread extends Thread {
    public String getChannel2() {
        return channel2;
    }
}
