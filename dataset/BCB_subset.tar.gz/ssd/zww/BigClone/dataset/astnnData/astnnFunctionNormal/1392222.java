class BackupThread extends Thread {
    public int getChannels() {
        return channels;
    }
}
