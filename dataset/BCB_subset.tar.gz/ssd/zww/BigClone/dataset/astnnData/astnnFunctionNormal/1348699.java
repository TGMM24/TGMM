class BackupThread extends Thread {
    @Override
    public SocketChannel getChannel() {
        return channel;
    }
}
