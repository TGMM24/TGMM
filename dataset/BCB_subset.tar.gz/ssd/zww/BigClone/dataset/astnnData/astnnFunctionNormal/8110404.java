class BackupThread extends Thread {
    public ChannelWorldInterface getChannel(int channel) {
        return channelServer.get(channel);
    }
}
