class BackupThread extends Thread {
    public void killOpenPressed() {
        ChannelFrame.filterChooserFrame.choiceMade("shutter");
        ChannelFrame.filterPanel.getChannelDisplay().getPattern().killOpenPressed();
    }
}
