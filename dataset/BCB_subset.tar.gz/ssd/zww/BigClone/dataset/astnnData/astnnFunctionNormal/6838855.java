class BackupThread extends Thread {
    public int getChannelAge() {
        return m_channel_age;
    }
}
