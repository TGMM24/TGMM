class BackupThread extends Thread {
    public FileChannel getChannel() {
        return channel;
    }
}
