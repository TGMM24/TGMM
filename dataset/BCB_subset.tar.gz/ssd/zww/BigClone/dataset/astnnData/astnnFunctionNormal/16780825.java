class BackupThread extends Thread {
    public ChannelReader(File f) throws IOException {
        this(new FileInputStream(f).getChannel());
    }
}
