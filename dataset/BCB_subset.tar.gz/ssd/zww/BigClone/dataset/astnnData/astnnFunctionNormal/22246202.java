class BackupThread extends Thread {
    public String getChannel() {
        return channel;
    }
}
