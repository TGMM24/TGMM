class BackupThread extends Thread {
    public long getChannelIdleTimeoutMillis() {
        return gravityConfig.getChannelIdleTimeoutMillis();
    }
}
