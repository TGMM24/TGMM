class BackupThread extends Thread {
    public String getChannelName() {
        return channelName;
    }
}
