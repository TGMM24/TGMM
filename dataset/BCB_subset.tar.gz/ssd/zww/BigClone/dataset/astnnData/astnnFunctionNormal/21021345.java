class BackupThread extends Thread {
    public Channel getChannel() {
        return channel;
    }
}
