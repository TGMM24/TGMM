class BackupThread extends Thread {
            public short[] getChannelValues(short[] addresses) {
                return model.getChannelValues(addresses);
            }
}
