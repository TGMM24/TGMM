class BackupThread extends Thread {
    public int getChannelFlags() {
        return channelFlags;
    }
}
