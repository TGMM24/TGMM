class BackupThread extends Thread {
    public List<Channel> getChannels() {
        return new ArrayList<Channel>(this.channels.values());
    }
}
