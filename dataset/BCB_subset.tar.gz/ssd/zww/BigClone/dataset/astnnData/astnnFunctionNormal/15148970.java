class BackupThread extends Thread {
    public String getChannelPath() {
        return channelPath;
    }
}
