class BackupThread extends Thread {
    public int getChannelVerticalposition() {
        return sp_vertical.getDividerLocation();
    }
}
