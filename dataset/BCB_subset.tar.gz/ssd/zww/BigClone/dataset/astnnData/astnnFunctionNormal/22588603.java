class BackupThread extends Thread {
    public void setReadWriteMode(boolean readWriteMode) {
        m_read_write_mode = readWriteMode;
    }
}
