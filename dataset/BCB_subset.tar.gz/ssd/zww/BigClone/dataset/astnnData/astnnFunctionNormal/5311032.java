class BackupThread extends Thread {
    public SmtpChannelSpecification getChannelObject() {
        return channelObject;
    }
}
