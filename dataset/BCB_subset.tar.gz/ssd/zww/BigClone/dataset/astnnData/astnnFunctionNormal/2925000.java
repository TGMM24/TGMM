class BackupThread extends Thread {
        public ChannelRecord getChannelRecord() {
            return record;
        }
}
