class BackupThread extends Thread {
    public int getChannelInformation() {
        return channelInformation;
    }
}
