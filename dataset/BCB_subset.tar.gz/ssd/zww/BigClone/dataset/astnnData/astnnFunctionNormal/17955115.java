class BackupThread extends Thread {
    public static byte[] getSha1(final byte[] data) {
        return getSha1Digest().digest(data);
    }
}
