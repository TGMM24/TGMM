class BackupThread extends Thread {
    @Override
    public Color getChannelColor() {
        return InvigGreen;
    }
}
